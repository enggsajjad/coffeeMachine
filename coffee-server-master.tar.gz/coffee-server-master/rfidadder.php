<?php

    header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
    header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Datum in der Vergangenheit

    include("global_stuff.php");

    if($_REQUEST['codewort'] != "42!") {
	die ("Wrong Code");
    }

    
    $UserID=substr($_REQUEST['user'],0, strpos($_REQUEST['user'],"_"));
    $val=$_REQUEST['value'];

      $sql = "INSERT INTO `rfid` (`userid`, `rfid`) VALUES ('".mysqli_real_escape_string($link, $UserID)."', '".mysqli_real_escape_string($link, $val)."');";
      echo mysqli_query($link, $sql);




?>

<a href="kasse.php">back zur Kasse</a>

</body></html>
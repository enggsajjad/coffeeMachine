<?php

    header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
    header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Datum in der Vergangenheit
    header("Content-Type: text/html; charset=utf-8");
?>
<?php

include("global_stuff.php");
mysqli_set_charset($link, "utf8");

  if($_REQUEST['secret'] != "42!") { header("HTTP/1.0 404 Not Found"); die(); }
   
    $sql = "SELECT Name, user.id as UserID, rfid.rfid as rfid, user.mode as mode, token.token as token FROM token,`user` LEFT JOIN `rfid` ON rfid.userid=user.id WHERE user.id > 0 AND token.userid=user.id ORDER BY user.id asc";
    $ergebnis=mysqli_query($link, $sql);
    for ($i=0; $i< mysqli_num_rows($ergebnis); $i++) {
	echo mysqli_result($ergebnis,$i,"UserID")."; ".mysqli_result($ergebnis,$i,"Name")."; ".mysqli_result($ergebnis,$i,"rfid")."; ".mysqli_result($ergebnis,$i,"mode")."; ".mysqli_result($ergebnis,$i,"token")."\n";
    }


?>

<?php

$__CredPayment="2390489023841239234862347863g24khgdfjg,ejkghdfj";

include("global_stuff.php");
mysqli_query($link, "SET NAMES 'utf8'");


//first: see if new coffe counter was submitted

if (isset($_REQUEST['coffecount'])) {
if($_REQUEST['codewort'] != $__CredPayment) {
  die ("Wrong Code");
}

$result = mysqli_query($link, "select wert from MaschinenStand order by timestamp limit 1;");
$old_count = mysqli_result($result, 0, 'wert');

if($_REQUEST['coffecount'] <= (int)$old_count) {
  die ("Coffe count must grow monotonic");
}

$result = mysqli_query($link, "insert into MaschinenStand  (wert) VALUES (".mysqli_real_escape_string($link, $_REQUEST['coffecount']).");");

header("decalcify.php", true, 302);
}


//second: generate status

$template = "decalcify.pml";

$data = new StdClass;
$data->eventNotification="";
 
    
$result=mysqli_query($link, "select next.timestamp as date,DATEDIFF(next.timestamp,first.timestamp) as tdiff, ((next.wert-first.wert)/DATEDIFF(next.timestamp,first.timestamp)) as cofPday,(next.wert-first.wert) as diff from MaschinenStand as first join (MaschinenStand as next) on (next.timestamp>first.timestamp) group by first.timestamp");

/* list of maintenance jobs, days,coffee and coffe per day since last maintenace */
for ($i=0; $i< mysqli_num_rows($result); $i++) {
   $entry->date=mysqli_result($result,$i,"date");
   $entry->dayDiff=mysqli_result($result,$i,"tdiff");
   $entry->coffeeDiff=mysqli_result($result,$i,"diff");
   $entry->coffeePerDay=mysqli_result($result,$i,"cofPday");
   $data->maintenanceList[] = $entry;
   unset($entry);
}
 
//averages over maintenace jobs
$result=mysqli_query($link, "select AVG(t1.tdiff) as avgDays, AVG(t1.diff) as avgCoffee ,AVG(t1.cofPday) as avgCoffeePerDay from (select next.timestamp as date,DATEDIFF(next.timestamp,first.timestamp) as tdiff, ((next.wert-first.wert)/DATEDIFF(next.timestamp,first.timestamp)) as cofPday,(next.wert-first.wert) as diff from MaschinenStand as first join (MaschinenStand as next) on (next.timestamp>first.timestamp) group by first.timestamp) as t1;");
$data->avgDays = mysqli_result($result,0,"avgDays");
$data->avgCoffee = mysqli_result($result,0,"avgCoffee");
$data->avgCoffeePerDay = mysqli_result($result,0,"avgCoffeePerDay");

//last maintenance jobs
$result=mysqli_query($link, "select timestamp as lastDays, wert as lastCoffee from MaschinenStand order by timestamp DESC limit 1;");
$data->lastDays = mysqli_result($result,0,"lastDays");
$data->lastCoffee = mysqli_result($result,0,"lastCoffee");

//not implemented
//$result=mysqli_query($link, "select timestamp as lastDays, wert as lastCoffee from MaschinenStand order by timestamp limit 1;");
//$data->totalCoffee =mysqli_result($result,0,"lastCoffee"); 

//prediction for next maintenance
$data->nextDays = new DateTime($data->lastDays);
date_add($data->nextDays, new DateInterval('P' . round($data->avgDays) . 'D'));
$data->nextCoffee = $data->lastCoffee + $data->avgCoffee;




header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Datum in der Vergangenheit   
include ($template);
?>

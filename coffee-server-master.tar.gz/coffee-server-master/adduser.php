<?php

    header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
    header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Datum in der Vergangenheit

    include("global_stuff.php");

    echo '<h1>Add new User</h1>';
    echo '<h2><font color="red">New users must pay 5&euro;!!!!</font></h2>';

    if ($_REQUEST['name'] != "") {
	addUser($_REQUEST['name']);
    } else {
	echo 'if (Student) then add Betreuerinitialen in Klammer!<br>
	<form action="adduser.php" method="post">
	    <p>Name:&nbsp;<input name="name" type="text" size="30" maxlength="40"></p>
	</form>	';
    }




function genToken($Name) {
    return substr(md5("KaFFee+".$Name."Kaffee"),0,5);
}

function addUser($Name) {
    mysqli_query($link,  "INSERT into `user` (name) VALUES ('".mysqli_real_escape_string($link, $Name)."')" );
    $UserID=mysqli_insert_id($link);
    echo "UserID: $UserID<br>";
    mysqli_query($link,  "INSERT into `token` (userid, token) VALUES (\"$UserID\", \"".genToken($Name)."\")" );
    echo "Online Account: http://i80web2.ira.uka.de/coffee/kasse.php?token=".genToken($Name)."<br>";
    echo "Token for Android App: ".genToken($Name);
}


?>

</body></html>

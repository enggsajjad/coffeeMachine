<?php
include("global_stuff.php");
mysqli_query($link, "SET NAMES 'utf8'");

$template = "kasse.pml";

$data = new StdClass;
$data->eventNotification="";
$data->token = $_REQUEST['token'];
if($data->token == C0FFE)
   $template = "kasse.tablet.pml";

$data->login=false;
 
    
if ( $data->token != "") {
    $ergebnis=mysqli_query($link, "SELECT id, name, hidden FROM user, token where id=userid and token.token='".addslashes(substr($data->token,0,5))."'");
	if(mysqli_num_rows($ergebnis) == 0) {
	    die("wrong token");
	} else {
	    $data->login=true;
	    $data->name=mysqli_result($ergebnis,0,"name");
	    $data->hidden=mysqli_result($ergebnis,0,"hidden");
	    $data->userID=mysqli_result($ergebnis,0,"id");
    }

    if(getUserID() == 93) {	// ADMIN USER :D
        $data->isAdmin = true;
    } else {
        $data->isAdmin = false;
    }

    $ergebnis=mysqli_query($link, "SELECT timestamp, preis FROM `KaffeePreis` order by ID desc LIMIT 1");
    $data->kaffeePreis=mysqli_result($ergebnis,0,"preis")/100;
    $data->timestamp = mysqli_result($ergebnis,0,"timestamp");

    $ergebnis=mysqli_query($link, "SELECT timestamp, preis FROM `MilchPreis` order by ID desc LIMIT 1");
    $data->milchPreis=mysqli_result($ergebnis,0,"preis")/100;

    $data->timestamp_milk = mysqli_result($ergebnis,0,"timestamp");

    $ergebnis=mysqli_query($link, "SELECT sum(Value) as Kontostand FROM `protokoll` WHERE protokoll.UserID=$data->userID group by UserID order by Kontostand");
    $data->kontostand=mysqli_result($ergebnis,0,"Kontostand")/100;
    $data->color=getColor($data->kontostand);
    
    
    if($data->login) {

        $ergebnis=mysqli_query($link, "SELECT sum(Value) as Einzahlungen FROM `protokoll` WHERE LEFT(kommentar, 10) = 'eingezahlt' ");
        $data->einzahlungen=(mysqli_result($ergebnis,0,"Einzahlungen")/100);

        $ergebnis=mysqli_query($link, "SELECT sum(Value) as Ausgaben FROM `protokoll` WHERE UserID=0 ");
        $data->ausgaben=(mysqli_result($ergebnis,0,"Ausgaben")/100);
        
        $ergebnis=mysqli_query($link, "SELECT sum(Value) as Userbalance FROM `protokoll` WHERE UserID>0 ");
        $data->userbalance=(mysqli_result($ergebnis,0,"Userbalance")/100);

        $data->kassenstand=$data->einzahlungen+$data->ausgaben;
        $data->polster=$data->einzahlungen+$data->ausgaben-$data->userbalance;

        $ergebnis=mysqli_query($link, "SELECT user.Name as Name, sum(Value) as Kontostand FROM `protokoll`, `user` WHERE protokoll.UserID=user.id AND hidden='no' AND inactive='no' AND UserID>0 group by UserID order by Kontostand");
        for ($i=0; $i< mysqli_num_rows($ergebnis); $i++) {
            $entry->kontostand=mysqli_result($ergebnis,$i,"Kontostand")/100;
            $entry->color = getColor($entry->kontostand);
            $entry->name=mysqli_result($ergebnis,$i,"Name");
            $data->userList[] = $entry;
            unset($entry);
        }

        $ergebnis=mysqli_query($link, "SELECT user.name AS name, count( protokoll.value ) AS summeday
    FROM user, protokoll
    WHERE user.id = protokoll.UserID
    AND hidden='no'
    AND UserID > 0
    AND LEFT(Kommentar,3)='Buy'
    AND Value<-3
    AND TIMESTAMPDIFF( HOUR ,
    CURRENT_TIMESTAMP , protokoll.time ) > -24
    GROUP BY name
    ORDER BY summeday DESC");
        
        for ($i=0; $i< mysqli_num_rows($ergebnis); $i++) {
            $entry->count=mysqli_result($ergebnis,$i,"summeday");
            $entry->name=mysqli_result($ergebnis,$i,"name");
            $data->summeday[] = $entry;
            unset($entry);
        }
        
        $sql = 'select name, verbraucht.UserID, IFNULL(verbraucht.Summe, 0) as verbrauchtSumme, IFNULL(gekauft.Summe,0) as gekauftSumme,  IFNULL(verbraucht.Summe, 0) + IFNULL(gekauft.Summe,0) as GMGvalue from 
((SELECT UserID, sum(Value*(3/25)) as Summe FROM protokoll WHERE value < 0 AND Kommentar LIKE "%Milk%" group by UserID) as verbraucht
 LEFT OUTER JOIN
(SELECT UserID, sum(Value) as Summe FROM protokoll WHERE value > 0 AND Kommentar LIKE "%Milch%" group by UserID) as gekauft 


ON gekauft.UserID=verbraucht.UserID), user WHERE user.id=verbraucht.UserID and user.hidden="no" and user.inactive="no" order by GMGvalue DESC';
        //echo $sql;
        $ergebnis=mysqli_query($link, $sql);
        for ($i=0; $i< 5 /*mysqli_num_rows($ergebnis)*/; $i++) {
            $entry->name = mysqli_result($ergebnis,$i,"name");
            $entry->summe=mysqli_result($ergebnis,$i,"verbrauchtSumme")/100;
            $entry->gekauft=mysqli_result($ergebnis,$i,"gekauftSumme")/100;
            $entry->ratio=mysqli_result($ergebnis,$i,"GMGvalue")/100;
            if($entry->ratio <= 0) {
                //break;
            }
            $data->goodMilkGuys[]=$entry;
            unset($entry);
        }	    

        for ($i=mysqli_num_rows($ergebnis)-1; $i> mysqli_num_rows($ergebnis)-11 ; $i--) {
            $entry->name = mysqli_result($ergebnis,$i,"name");
            $entry->summe=mysqli_result($ergebnis,$i,"verbrauchtSumme")/100;
            $entry->gekauft=mysqli_result($ergebnis,$i,"gekauftSumme")/100;
            $entry->ratio=mysqli_result($ergebnis,$i,"GMGvalue")/100;
            if($entry->ratio > 0) {
                break;
            }
            $data->badMilkGuys[]=$entry;
            unset($entry);
        }	    

        $ergebnis=mysqli_query($link, "SELECT ((SELECT sum(Value) from protokoll where Kommentar like \"%Milch%\" and UserID>0)+(SELECT sum(Value) from protokoll where Kommentar like \"%Milch%\" and UserID=0)) as offset");
        $data->offset = ToEuro(-mysqli_result($ergebnis,0,"offset"));
        
        $ergebnis=mysqli_query($link, "SELECT user.name AS name, sum( protokoll.value ) AS summeday
    FROM user, protokoll
    WHERE user.id = protokoll.UserID
    AND hidden='no'
    AND UserID > 0
    AND (LEFT(Kommentar,3)='Buy' OR LEFT(Kommentar,3)='Str')
    AND TIMESTAMPDIFF( DAY ,
    CURRENT_TIMESTAMP , protokoll.time ) > -30
    GROUP BY name
    ORDER BY summeday ASC");
        $MaxCount=0;
        for ($i=0; $i< mysqli_num_rows($ergebnis); $i++) {
            $entry->count=mysqli_result($ergebnis,$i,"summeday")/-100;
            if($i==0) {
                $MaxCount=$entry->count;
                $entry->count=10;
            } else {
                $entry->count=($entry->count/$MaxCount)*10;
            }
            $entry->name = mysqli_result($ergebnis,$i,"name");
            $data->stats30[] = $entry;
            unset($entry);
        }
        
        $ergebnis=mysqli_query($link, "SELECT protokoll.id as id, name, time, value, actions.text as ActionText, kommentar FROM `protokoll`, `user`, `actions` where protokoll.UserID=user.id AND actions.id=protokoll.ActionID AND hidden='no' order by time desc LIMIT 0,50");
        for ($i=0; $i< mysqli_num_rows($ergebnis); $i++) {
            $entry->value=sprintf("%.02f",(mysqli_result($ergebnis,$i,"value")/100));
            $entry->color = getColor($entry->value);
            $entry->time = mysqli_result($ergebnis,$i,"time");
            $entry->name = mysqli_result($ergebnis,$i,"name");
            $entry->actionText = mysqli_result($ergebnis,$i,"ActionText");
            $entry->kommentar = mysqli_result($ergebnis,$i,"kommentar");
            $data->actionLog[] = $entry;

            unset($entry);
            
        }
    }
}

header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Datum in der Vergangenheit   
include ($template);
?>

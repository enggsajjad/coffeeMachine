<?php

    header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
    header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Datum in der Vergangenheit

?>

<html>
<head>
    <meta http-equiv="expires" content="0">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="pragma" content="no-cache">
</head><body>


<style type="text/css">
<!--
    td {padding-right: 25px;}
    th {padding-right: 25px;}

hr {

  width: 95%;
  color: #CCFCED;
  background-color: #CCFCED;


}

input, select{ width:200px;} 

-->
</style>

<script type="text/javascript">
<!--
//Hier werden später die Optionen zwischengelagert
arrWb = false;

function autoindex()
{
    //Texteingabefeld
    objInput = document.f1.eingabe;
    
    //Liste
    objList = document.f1.user;
    
    //"Wörterbuch" beim ersten Aufruf anlegen
    if(!arrWb)
        {
            arrWb=new Array();
            for(j=0;j<objList.options.length;++j)
                {
                    arrWb.push(
                                new Option(
                                            objList.options[j].text,
                                            (objList.options[j].value=='')
                                                ? objList.options[j].text
                                                : objList.options[j].value)
                                           );
                }
        }     
    
    //Liste leeren
    objList.options.length = 0;
    
    //Liste neu füllen
    for(k=0;k<arrWb.length;++k)
        {
        if(objInput.value==''||arrWb[k].text.match(new RegExp(objInput.value,'i')))
            {
                objList.options[objList.options.length]=arrWb[k];
            }
        }
}

//-->
</script>

<?php

include("global_stuff.php");

    $ergebnis=mysqli_query($link, "SELECT now() as jetzt");
    echo "<center><h3>Super Secret Special Payment Maker</h3></center>";
    echo '<table><tr><td><form action="paymentmaker.php" method="post" name="f1">';
    echo '<input name="eingabe" type="text" onkeyup="autoindex()" onmouseup="autoindex()" onchange="autoindex()" autocomplete="off"><br>';
    
    echo '</td><td><select name="user" size="5">';
    $sql = "SELECT Name, user.id as UserID, sum(value) as Kontostand FROM `user` LEFT OUTER JOIN `protokoll` ON protokoll.UserID=user.id WHERE user.id > 0 GROUP BY user.id ORDER BY user.id asc";
    $ergebnis=mysqli_query($link, $sql);
    for ($i=0; $i< mysqli_num_rows($ergebnis); $i++) {
	echo "<option>".mysqli_result($ergebnis,$i,"UserID")."_".mysqli_result($ergebnis,$i,"Name")."</option>";
    }
    echo '</select></td></tr></table><br>';

    echo 'Betrag: <input type="text" name="value"> (Cents!)<br>';
    echo 'Typ: <input type="text" name="typ"> ( Bargeld / 1 Sack Kaffeebohnen / 1 Packung Milch / Wasserfilter / Entkalker / Freitext )<br>';
    echo 'Gebrauchsmaterial (alles ausser Bargeld): <input type="checkbox" name="consume" value="true"><br>';
    echo '<b>NUR verbrauche, ohne einzahlen</b>: <input type="checkbox" name="consumeonly" value="true"><br>';
    echo 'Super Secret Codewort: <input type="password" name="codewort"><br>';

    echo '<input type="submit" value="Formulardaten absenden"></form>';


?>


</body></html>
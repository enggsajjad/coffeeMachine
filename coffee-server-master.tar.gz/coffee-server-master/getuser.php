<?php

    header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
    header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Datum in der Vergangenheit

?>
<?php

include("global_stuff.php");
    mysqli_query($link, "SET NAMES 'utf8'");
    $ergebnis=mysqli_query($link, "SELECT now() as jetzt");

    $sql = "SELECT Name, user.id as UserID, sum(value) as Kontostand, mode, token.token as token FROM token, `user` LEFT OUTER JOIN `protokoll` ON protokoll.UserID=user.id WHERE user.id = '".getUserID()."' AND token.userid=user.id GROUP BY user.id ORDER BY user.id asc";
    $ergebnis=mysqli_query($link, $sql);
	$Name="";
	$Kontostand=0;
    for ($i=0; $i< mysqli_num_rows($ergebnis); $i++) {
	echo mysqli_result($ergebnis,$i,"UserID")."; ".mysqli_result($ergebnis,$i,"Name")."; ".mysqli_result($ergebnis,$i,"Kontostand")."; ".mysqli_result($ergebnis,$i,"mode")."; ".mysqli_result($ergebnis,$i,"token")."; ";

        $Name=mysqli_result($ergebnis,$i,"Name");
        $Kontostand=mysqli_result($ergebnis,$i,"Kontostand");

    }
 
    if($Name == "Martin Haaß") {
	$Name="der mit den kapütten Ümläutenß";
    }


    $Name=htmlentities($Name, ENT_COMPAT | ENT_HTML401, "UTF-8");	// fixt utf8 im webkit

    $ShowMessage=true;
    $BGColor="#000000";
    $TextColor="#ffffff";
    $BarColor="black";
    $Message="Nothing to see here!";
    $SubMessage="Go Away!";

    if($Kontostand < 0) {
	echo "no\n"; 	// forbid consumption of coffee
	$BGColor="#000000";
	$TextColor="#ffffff";
	$Message="Coffee output denied!";
	$BarColor="white";	
	$SubMessage="Pay your liabilities enable coffee output!<br>Hint: You can also buy milk to replenish your account!";
    } else if($Kontostand < 50 ) {
	echo "yes\n"; 	// allow consumption of coffee
	$BGColor="#FF0000";
	$TextColor="#000000";
	$Message="Account balance warning!";
	$BarColor="black";	
	$SubMessage="Please pay your liabilities as soon as possible!<br>Hint: You can also buy milk to replenish your account!";
    } else if($Kontostand < 300 ) {
	echo "yes\n";   // allow consumption of coffee
	$BGColor="#FFFF00";
	$TextColor="#000000";
	$Message="Account balance information!";
	$BarColor="black";	
	$SubMessage="Please consider depositing money in your coffee account!<br>Hint: You can also buy milk to replenish your account!";
    } else {
	echo "yes\n"; 	// allow consumption of coffee
	$ShowMessage=false;
    }

    if($ShowMessage) {
        echo '<html><head>';
        echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">";
        echo "</head><body bgcolor=\"$BGColor\" text=\"$TextColor\">";
        echo "<center>  <h1>$Message</h1><br><br>\n";
        echo "  <h2>Dear $Name,<br><br>your balance is currently</h2><br><br><div style=\"background-color:$BarColor\"><h1>".ToEuro($Kontostand)."<h1></div><h2><br><br>$SubMessage</h2>\n";
        echo "</center></body></html>\n";
    }


?>

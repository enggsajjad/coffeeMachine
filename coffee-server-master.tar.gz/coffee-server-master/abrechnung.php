<?php

    header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
    header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Datum in der Vergangenheit

    echo "Hi!<br>";

    include("global_stuff.php");

    foreach($_REQUEST as $key=>$val)  {

	if(substr($key,0,6) == "abrid_") {
	    $UserID=substr($key,6);
	    if(is_numeric($UserID) && is_numeric($val) && $val > 0) {
		echo "Abrechning:".$UserID.": ".$val."<br>";
		$sql = "INSERT INTO `protokoll` (`id`, `UserID`, `Time`, `Value`, `Kommentar`, `ActionID`) VALUES (NULL, ".mysqli_real_escape_string($link, $UserID).", CURRENT_TIMESTAMP, (".mysqli_real_escape_string($link, $val)."*((SELECT preis FROM KaffeePreis order by id desc LIMIT 1)+(SELECT preis FROM MilchPreis order by id desc LIMIT 1))), 'Strichlistenabrechnung: ".mysqli_real_escape_string($link, $val)." Coffee with Milk', (SELECT id from actions where text='Tally Sheet'));";
		echo mysqli_query($link, $sql);
	    }
	}

	if(substr($key,0,12) == "abridnomilk_") {
	    $UserID=substr($key,12);
	    if(is_numeric($UserID) && is_numeric($val) && $val > 0) {
		echo "Abrechning:".$UserID.": ".$val."<br>";
		$sql = "INSERT INTO `protokoll` (`id`, `UserID`, `Time`, `Value`, `Kommentar`, `ActionID`) VALUES (NULL, ".mysqli_real_escape_string($link, $UserID).", CURRENT_TIMESTAMP, (".mysqli_real_escape_string($link, $val)."*(SELECT preis FROM KaffeePreis order by id desc LIMIT 1)), 'Strichlistenabrechnung: ".mysqli_real_escape_string($link, $val)." Black Coffee', (SELECT id from actions where text='Tally Sheet'));";
		echo mysqli_query($link, $sql);
	    }
	}
	

    }


?>

<a href="kasse.php">back zur Kasse</a>

</body></html>

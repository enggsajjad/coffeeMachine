    <?php

    include "credentials.php";

    if( !$link = mysqli_connect ($host,$user,$pass,$db)) {
		die ("fail: SQL DB failed");
    }

    function mysqli_result($res,$row=0,$col=0){ 
        $numrows = mysqli_num_rows($res); 
        if ($numrows && $row <= ($numrows-1) && $row >=0){
            mysqli_data_seek($res,$row);
            $resrow = (is_numeric($col)) ? mysqli_fetch_row($res) : mysqli_fetch_assoc($res);
            if (isset($resrow[$col])){
                return $resrow[$col];
            }
        }
        return false;
    }

    $__UserID=0;
    
    function getUserID() {
      global $__UserID, $link;

      if($__UserID != 0) return $__UserID;
    
      $Token=substr($_REQUEST['token'],0,5);
      $rfid=$_REQUEST['rfid'];
      $sql = "";

      if($Token != "") {
	$sql="SELECT userid FROM `token` WHERE token = '".mysqli_real_escape_string($link, $Token)."'";
      }
      if($rfid != "") {
	$sql="SELECT userid FROM `rfid` WHERE lower(rfid) = lower('".mysqli_real_escape_string($link, $rfid)."')";
      }
      $ergebnis=mysqli_query($link, $sql);

      if(mysqli_num_rows($ergebnis) == 1) {
	    $__UserID = mysqli_result($ergebnis,0,"userid");
      } else {
	  if($rfid!= "") {
	      $sql="INSERT INTO unknownrfids (`rfid` , `time`) VALUES ( '".mysqli_real_escape_string($link, $rfid)."', CURRENT_TIMESTAMP );";
	      mysqli_query($link, $sql);
	  }
	  die("unknown token/rfid: ".$Token);
      }
      
      return $__UserID;
    }

    function ToEuro($Wert) {
            $Value=sprintf("%.02f",($Wert/100));
            if($Value < 0) {
              $Value = "<font color=red>$Value&euro;</font>";
            } else if($Value == 0) {
              $Value = "<font color=blue>$Value&euro;</font>";
            } else {
              $Value = "<font color=green>$Value&euro;</font>";
            }
            return $Value;
    }

    function getColor($value) {
        if($value < 0) 
            $color = "red";
        elseif($value == 0) 
            $color = "blue";
        else
            $color = "green";
        return $color;
    }

    ?>

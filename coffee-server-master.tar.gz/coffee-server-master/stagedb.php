<?php
  include "credentials.php";

  # do not use locks in coffee - we don't have permission to.
  exec("mysqlidump -u coffee-stage -p'$pass' --skip-lock-tables coffee | mysqli -u coffee-stage -p'$pass' coffee-stage");
?>

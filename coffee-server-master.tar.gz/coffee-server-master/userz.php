<?php

    header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
    header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Datum in der Vergangenheit

?>
<?php

include("global_stuff.php");

    $ergebnis=mysqli_query($link, "SELECT now() as jetzt");
  
    $sql = "SELECT Name, user.id as UserID, sum(value) as Kontostand FROM `user` LEFT OUTER JOIN `protokoll` ON protokoll.UserID=user.id WHERE user.id > 0 GROUP BY user.id ORDER BY user.id asc";
    $ergebnis=mysqli_query($link, $sql);
    echo "ID, Name, Kontostand\n";
    for ($i=0; $i< mysqli_num_rows($ergebnis); $i++) {
	echo mysqli_result($ergebnis,$i,"UserID").", ".mysqli_result($ergebnis,$i,"Name").", ".mysqli_result($ergebnis,$i,"Kontostand")."\n";
    }


?>

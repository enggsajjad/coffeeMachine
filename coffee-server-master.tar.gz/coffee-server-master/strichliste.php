<?php

    header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
    header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Datum in der Vergangenheit

?>

<html>
<head>
    <meta http-equiv="expires" content="0">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="pragma" content="no-cache">
</head><body>

<style type="text/css">
<!--
    td {padding-right: 25px;}
    th {padding-right: 25px;}

hr {

  width: 95%;
  color: #CCFCED;
  background-color: #CCFCED;


}

-->
</style>

<?php

    $__CredStrichliste="23478723859dfgsdjfvjv23gv4öoij";

include("global_stuff.php");

    $codewort=$__CredStrichliste; 


    $ergebnis=mysqli_query($link, "SELECT now() as jetzt");
    echo "<center><h3>Kaffee-Strichliste ab ".mysqli_result($ergebnis,0,"jetzt")."</h3>";

    //$ergebnis=mysqli_query($link, "SELECT sum(Value) as Kassenstand FROM `protokoll` WHERE 1");
    //echo "Kassenstand: ".(mysqli_result($ergebnis,0,"Kassenstand")/100)."&euro;, aktueller ";

    $ergebnis=mysqli_query($link, "SELECT timestamp, preis FROM `KaffeePreis` order by ID desc LIMIT 1");
    $Kaffeepreis=mysqli_result($ergebnis,0,"preis");

    $ergebnis=mysqli_query($link, "SELECT timestamp, preis FROM `MilchPreis` order by ID desc LIMIT 1");
    $Milchpreis=-mysqli_result($ergebnis,0,"preis");

    $ergebnis=mysqli_query($link, "SELECT timestamp, preis FROM `KaffeePreis` order by ID desc LIMIT 1");
    echo "Price of one cup: ".(mysqli_result($ergebnis,0,"preis")/-100)."&euro; since ".mysqli_result($ergebnis,0,"timestamp").". Milk per cup: $Milchpreis Cent<br></center>";

    if ($_REQUEST['admin'] == $codewort) {
	echo '<form action="abrechnung.php" method="post">';
    }

    $sql = "SELECT Name, user.id as UserID, sum(value) as Kontostand FROM `user` LEFT OUTER JOIN `protokoll` ON protokoll.UserID=user.id WHERE user.id > 0 AND inactive = 'no' GROUP BY user.id ORDER BY user.id asc";
    $ergebnis=mysqli_query($link, $sql);
    echo "<table border=\"1px\" padding=\"0px\" cellspacing=\"0\" cellpadding=\"0\"><tr><th>Name</th><!--<th style=\"text-align:center\">Kontostand</th>--><th width=\"100%\">Strichliste</th></tr>";
    for ($i=0; $i< mysqli_num_rows($ergebnis); $i++) {
	echo "<tr><td><nobr>".mysqli_result($ergebnis,$i,"UserID").".<b>".mysqli_result($ergebnis,$i,"Name")."</b></nobr></td> <!-- <td ALIGN=\"right\">".sprintf("%.02f",(mysqli_result($ergebnis,$i,"Kontostand")/100))."&euro;</td> --> <td>";
	if ($_REQUEST['admin'] == $codewort) {
	    echo 'MilkC: <input type="text" name="abrid_'.mysqli_result($ergebnis,$i,"UserID").'"><br>';
	    echo 'Black:<input type="text" name="abridnomilk_'.mysqli_result($ergebnis,$i,"UserID").'"><br>';
	} else {
	    echo "With Milk:<hr>Black Coffee:<br>";
	}

	echo "</td>";
    }

    if ($_REQUEST['admin'] == $codewort) {
	echo "<tr><td><a href=\"adduser.php\">Add User</a></td> <td>&nbsp;</td> <td><b> ACHTUNG! FORMULARDATEN GEHEN DABEI VERLOREN! </b></td>";
    } else {
	for ($i=0; $i< 5; $i++) {
	    echo "<tr><td>Neu?</td> <td>&nbsp;</td> <td><br><br></td>";
	}
    }

    echo "</table><br><br><br>";
    if ($_REQUEST['admin'] == $codewort) {
	echo '<input type="submit" value="Formulardaten absenden"></form>';
    }


?>
<center><font size="+1">
Student accounts <b>must</b> have the following format: <b>Firstname Lastname (SI)</b> where SI are the initials of the supervisor!<br>
<b>New users must pay an initial amount of 5&euro; at Sebastian (Room 314.4)</b>
</font></center>

</body></html>

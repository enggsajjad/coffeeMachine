<?php

    header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
    header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Datum in der Vergangenheit

    include("global_stuff.php");

    if($_REQUEST['codewort'] != "42!") {
	die ("Wrong Code");
    }
    
    $UserID=getUserID(); //$_REQUEST['lastuserid'];
    $val=$_REQUEST['message'];
    $protoID=$_REQUEST['iid'];

    $sql = "INSERT INTO `errorlog` (`LastUserID`, `message`, ProtokollID) VALUES ('".mysqli_real_escape_string($link, $UserID)."', '".mysqli_real_escape_string($link, $val)."', '".mysqli_real_escape_string($link, $protoID)."');";
    echo mysqli_query($link, $sql);

?>


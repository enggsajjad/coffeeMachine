<?php

    header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
    header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Datum in der Vergangenheit

    if ($_REQUEST['mobile'] != "true") {   echo '<html><head>
						    <meta http-equiv="expires" content="0">
						    <meta http-equiv="refresh" content="5;URL=\'kasse.php?token='.$_REQUEST['token'].'\'">
						    <meta http-equiv="cache-control" content="no-cache">
						    <meta http-equiv="pragma" content="no-cache">
						</head><body>';

					    echo '

						<style type="text/css">
						<!--
						    td {padding-right: 25px;}
						    th {padding-right: 25px;}
						-->
						</style>

					    ';


    }


    include("global_stuff.php");
    
    if(getUserID()==0) die("in a fire!");

    $Black=$_REQUEST['black'];
    $Water=$_REQUEST['water'];
    $Cheated=$_REQUEST['cheated'];

    
    $Kommentar=$_REQUEST['mobile'] != "true" ? "web" : "app";
    $Kommentar=$_REQUEST['rfid'] != "" ? "rfid" : $Kommentar;

    /*if($_REQUEST['mobile'] != "true" && (time()-$_REQUEST['t'])>5000) {
	die ("Session timeout!<br><a href=\"kasse.php?token=".substr($_REQUEST['token'],0,5)."\">Back to the overview</a>");
    }*/


    $sql="";

    $Product="Unknown";

	// Hier muss man jetzt entscheiden, welches Produkt bezogen wurde. Das hätte man mal ordentlich refaktorisieren sollen bevor man es erweitert. HAHAHAHAHAHAHAHAHA

   if($Cheated == "true") { // user tried to cheat, but app caught it
	if($Black != "true") {      // KAffee mit Milch


                                $Product="Cheated Coffee";

                                $sql = "INSERT INTO `protokoll` (`id`, `UserID`, `Time`, `Value`, `Kommentar`, `ActionID` ) VALUES (NULL, '".getUserID()."', CURRENT_TIMESTAMP, ((SELECT preis FROM KaffeePreis order by id desc LIMIT 1)+(SELECT preis FROM MilchPreis order by id desc LIMIT 1)), 'Cheated (".mysqli_real_escape_string($link, $Kommentar).") Coffee with Milk', (SELECT id FROM actions WHERE text='$Product') );";
                } else {        // Kaffee OHNE milch (Schwarz)


                                $Product="Cheated Coffee";

                                $sql = "INSERT INTO `protokoll` (`id`, `UserID`, `Time`, `Value`, `Kommentar`, `ActionID`) VALUES (NULL, '".getUserID()."', CURRENT_TIMESTAMP, (SELECT preis FROM KaffeePreis order by id desc LIMIT 1), 'Cheated (".mysqli_real_escape_string($link, $Kommentar).") Black Coffee', (SELECT id FROM actions WHERE text='$Product'));";
                }
   } else {
   	if($Water == "true") { // Produkt = Wasser
	
			$Product="Hot Water";
	
			$sql = "INSERT INTO `protokoll` (`id`, `UserID`, `Time`, `Value`, `Kommentar`, `ActionID`) VALUES (NULL, '".getUserID()."', CURRENT_TIMESTAMP, (SELECT preis FROM WasserPreis order by id desc LIMIT 1), 'Buy (".mysqli_real_escape_string($link, $Kommentar).") Hot Water', (SELECT id FROM actions WHERE text='$Product'));";
   	} else {	// Produkt = Kaffee
		    if($Black != "true") {	// KAffee mit Milch
	
	
				$Product="Coffee with Milk";
	
				$sql = "INSERT INTO `protokoll` (`id`, `UserID`, `Time`, `Value`, `Kommentar`, `ActionID` ) VALUES (NULL, '".getUserID()."', CURRENT_TIMESTAMP, ((SELECT preis FROM KaffeePreis order by id desc LIMIT 1)+(SELECT preis FROM MilchPreis order by id desc LIMIT 1)), 'Buy (".mysqli_real_escape_string($link, $Kommentar).") Coffee with Milk', (SELECT id FROM actions WHERE text='$Product') );";
	    	} else {	// Kaffee OHNE milch (Schwarz)
	
	
				$Product="Black Coffee";
	
				$sql = "INSERT INTO `protokoll` (`id`, `UserID`, `Time`, `Value`, `Kommentar`, `ActionID`) VALUES (NULL, '".getUserID()."', CURRENT_TIMESTAMP, (SELECT preis FROM KaffeePreis order by id desc LIMIT 1), 'Buy (".mysqli_real_escape_string($link, $Kommentar).") Black Coffee', (SELECT id FROM actions WHERE text='$Product'));";
	    	}
    	}
  }



	$LastID=0;
    if($_REQUEST['onlyinfo'] != "true") {
        $ergebnis=mysqli_query($link, $sql);
	$LastID=mysqli_insert_id($link);
	if ($_REQUEST['mobile'] != "true") { echo "<h1>Buy: ".mysqli_insert_id($link)."<br><br><a href=\"kasse.php?token=".substr($_REQUEST['token'],0,5)."\">Back to the overview</a> (auto-redirect after 5s)</h1><br>"; }
    }

    $sql="SELECT user.Name as Name, sum(Value) as Kontostand FROM `protokoll`, `user` WHERE protokoll.UserID=user.id and user.id  = '".getUserID()."' group by user.id";
    $ergebnis=mysqli_query($link, $sql);

    if ($_REQUEST['mobile'] != "true") {
	echo "<table><tr><th>Name</th><th>Kontostand</th></tr>";
	for ($i=0; $i< mysqli_num_rows($ergebnis); $i++) {
	    echo "<tr><td>".mysqli_result($ergebnis,$i,"Name")."</td> <td>".(mysqli_result($ergebnis,$i,"Kontostand")/100)."&euro;</td>";
	}
	echo "</table><br><br><br>";
    } else {
	if(mysqli_num_rows($ergebnis) == 0) {
	    echo "unknown; 0; ";
	} else {
	    echo mysqli_result($ergebnis,0,"Name")."; ".(mysqli_result($ergebnis,0,"Kontostand")/100)."; ";
	}
    }

    $ergebnis=mysqli_query($link, "SELECT user.name AS name, count( protokoll.value ) AS summeday
FROM user, protokoll
WHERE user.id = protokoll.UserID AND user.id= '".getUserID()."'
AND value < 0
AND TIMESTAMPDIFF( HOUR ,
CURRENT_TIMESTAMP , protokoll.time ) > -24
GROUP BY name
ORDER BY summeday DESC");

    if ($_REQUEST['mobile'] != "true") {
/*
    echo "<h1>Highscore</h1>";
    echo "<table><tr><th>Name</th><th>24h</th></tr>";
    for ($i=0; $i< mysqli_num_rows($ergebnis); $i++) {
	$count=mysqli_result($ergebnis,$i,"summeday");
		$PronBar="";
		for ($stern=0; $stern<$count; $stern++) {
			$PronBar.="<img src=\"http://gspb.noob.info/navpix/stern.png\" height=\"20px\">";
		}
	echo "<tr><td>".mysqli_result($ergebnis,$i,"name")."</td> <td>".$count."</td> <td> $PronBar </td></tr>";
    }
    echo "</table><br><br><br>";*/
    } else {
	if(mysqli_num_rows($ergebnis) == 0) {
	    echo "0; ";
	} else {
	    echo mysqli_result($ergebnis,0,"summeday")."; ";
	}
    }


    $ergebnis=mysqli_query($link, "SELECT name, time, value, kommentar FROM `protokoll`, `user` where protokoll.UserID=user.id and user.id = '".getUserID()."' order by time DESC LIMIT 0,15");

    if ($_REQUEST['mobile'] != "true") {

	echo "<table><tr><th>Zeit</th><th>Name</th><th>Wert</th><th>Kommentar</th></tr>";
	for ($i=0; $i< mysqli_num_rows($ergebnis); $i++) {
	    echo "<tr><td>".mysqli_result($ergebnis,$i,"time")."</td> <td>".mysqli_result($ergebnis,$i,"name")."</td> <td>".(mysqli_result($ergebnis,$i,"Value")/100)."&euro;</td> <td>".mysqli_result($ergebnis,$i,"kommentar")."</td>";
	}
	echo "</table><br><br><br>";
    } else {
	if(mysqli_num_rows($ergebnis) == 0) {
	    echo "0; 0; 0; ";
	} else {
	    for ($i=0; $i< mysqli_num_rows($ergebnis); $i++) {
		echo mysqli_result($ergebnis,$i,"time")."; 0; 0; ";
	    }
	}
        if($_REQUEST['rfid'] != "") {       // Wenn das Tablet die Anfrage geschickt hat schick ihr doch zum error claimen noch die letzte Insert-ID mit...
               echo $LastID."; ";
        }

    }

    if ($_REQUEST['mobile'] != "true") {   echo '
	</body></html>';
    }

?>

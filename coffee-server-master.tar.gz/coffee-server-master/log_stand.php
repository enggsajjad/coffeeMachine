<?php

include("global_stuff.php");

    $ergebnis=mysqli_query($link, "SELECT timestamp, wert FROM `MaschinenStand` ORDER BY `timestamp` DESC");
    echo "Zeit, Wert\n";
    for ($i=0; $i< mysqli_num_rows($ergebnis); $i++) {
	echo "".mysqli_result($ergebnis,$i,"timestamp").", ".mysqli_result($ergebnis,$i,"wert")."\n";
    }
?>
<?php

    header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
    header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Datum in der Vergangenheit

?>
<html>
<body>
<?php

include("global_stuff.php");

    $sql = "SELECT user.Name as name, ProtokollID, message, time FROM `user` JOIN `errorlog` ON errorlog.LastUserID=user.id ORDER BY time;";
    $ergebnis=mysqli_query($link, $sql);
    echo "<table border=1><tr><th>Name</th><th>Datum</th><th>protokollID</th><th>Message</th></tr>";
    for ($i=0; $i< mysqli_num_rows($ergebnis); $i++) {
	echo "<tr><td>".mysqli_result($ergebnis,$i,"name")."</td><td>".mysqli_result($ergebnis,$i,"time")."</td><td>".mysqli_result($ergebnis,$i,"ProtokollID")."</td><td>".mysqli_result($ergebnis,$i,"message")."</td></tr>";
    }
   echo "</table>";

?>

</body>
</html>

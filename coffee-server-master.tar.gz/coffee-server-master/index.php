<html>
  <body>
    <a href="kasse.php">Kasse</a>
  </body>
</html>
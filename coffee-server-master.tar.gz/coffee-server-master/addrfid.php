<?php

    header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
    header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Datum in der Vergangenheit

?>

<html>
<head>
    <meta http-equiv="expires" content="0">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="pragma" content="no-cache">
</head><body>


<style type="text/css">
<!--
    td {padding-right: 25px;}
    th {padding-right: 25px;}

hr {

  width: 95%;
  color: #CCFCED;
  background-color: #CCFCED;


}

input, select{ width:200px;} 

-->
</style>

<script type="text/javascript">
<!--
//Hier werden später die Optionen zwischengelagert
arrWb = false;

function autoindex()
{
    //Texteingabefeld
    objInput = document.f1.eingabe;
    
    //Liste
    objList = document.f1.user;
    
    //"Wörterbuch" beim ersten Aufruf anlegen
    if(!arrWb)
        {
            arrWb=new Array();
            for(j=0;j<objList.options.length;++j)
                {
                    arrWb.push(
                                new Option(
                                            objList.options[j].text,
                                            (objList.options[j].value=='')
                                                ? objList.options[j].text
                                                : objList.options[j].value)
                                           );
                }
        }     
    
    //Liste leeren
    objList.options.length = 0;
    
    //Liste neu füllen
    for(k=0;k<arrWb.length;++k)
        {
        if(objInput.value==''||arrWb[k].text.match(new RegExp(objInput.value,'i')))
            {
                objList.options[objList.options.length]=arrWb[k];
            }
        }
}

//-->
</script>

<?php


    include("global_stuff.php");


    $ergebnis=mysqli_query($link, "SELECT now() as jetzt");
    echo "<center><h1>Super Secret Special ADD RFID</h1></center>";
    echo '<h2>Remember: New users must pay initially 5&euro;!!!</h2>';
    echo '<table><tr><td><form action="rfidadder.php" method="post" name="f1">';
    echo '<input name="eingabe" type="text" onkeyup="autoindex()" onmouseup="autoindex()" onchange="autoindex()" autocomplete="off"><br>';
    
    echo '</td><td><select name="user" size="5">';
    $sql = "SELECT Name, user.id as UserID FROM `user` WHERE user.id > 0 ORDER BY user.id asc";
    $ergebnis=mysqli_query($link, $sql);
    for ($i=0; $i< mysqli_num_rows($ergebnis); $i++) {
	echo "<option>".mysqli_result($ergebnis,$i,"UserID")."_".mysqli_result($ergebnis,$i,"Name")."</option>";
    }
    echo '</select></td></tr></table><br>';

    echo 'RFID: <input type="text" name="value"><br>';
    echo 'Super Secret Codewort: <input type="password" name="codewort"><br>';

    echo '<input type="submit" value="Formulardaten absenden"></form><br><br><br>';

    $sql = "SELECT rfid, time FROM unknownrfids ORDER BY time desc limit 0,30";
    $ergebnis=mysqli_query($link, $sql);
    for ($i=0; $i< mysqli_num_rows($ergebnis); $i++) {
	echo "".mysqli_result($ergebnis,$i,"time").": ".mysqli_result($ergebnis,$i,"rfid")."<br>";
    }

    

?>


</body></html>

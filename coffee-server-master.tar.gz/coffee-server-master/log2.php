<?php

include("global_stuff.php");

    $ergebnis=mysqli_query($link, "SELECT user.name as `Name`,`Time`, `Value`, `Kommentar` FROM `protokoll`, `user` WHERE user.id=protokoll.UserID AND user.hidden='no' ORDER BY `protokoll`.`id` DESC");
    echo "Zeit, Name, Value, Kommentar\n";
    for ($i=0; $i< mysqli_num_rows($ergebnis); $i++) {
	echo "".mysqli_result($ergebnis,$i,"time").", ".mysqli_result($ergebnis,$i,"name").", ".mysqli_result($ergebnis,$i,"value").", ".str_replace(","," ",mysqli_result($ergebnis,$i,"kommentar"))."\n";
    }
?>
<?php

include("global_stuff.php");
    
    $pid=$_REQUEST['lastid'];

    $ergebnis=mysqli_query($link, "SELECT protokoll.id as pid, UserID, user.name as `Name`,`Time`, `Value`, `Kommentar` FROM `protokoll`, `user` WHERE user.id=protokoll.UserID AND protokoll.id >= $pid ORDER BY `protokoll`.`id` DESC");
    for ($i=0; $i< mysqli_num_rows($ergebnis); $i++) {
	echo mysqli_result($ergebnis,$i,"pid").", ".mysqli_result($ergebnis,$i,"time").", ".mysqli_result($ergebnis,$i,"UserID").", ".mysqli_result($ergebnis,$i,"name").", ".mysqli_result($ergebnis,$i,"value").", ".mysqli_result($ergebnis,$i,"kommentar")."\n";
    }
?>

<?php
  include "/var/www/coffee/credentials.php";
  $today = date('Y-m-d');

  exec("mysqldump --user=$user --password='$pass' --host=localhost $db > /localhome/coffee/dbdumps/$today.sql");
//  exec("mysqldump --user=$user --password='$pass' --host=localhost $db > /var/www/coffee/dbdumps/$today.sql");
  exec("gzip /localhome/coffee/dbdumps/$today.sql");
//  exec("gzip /var/www/coffee/dbdumps/$today.sql");
?>

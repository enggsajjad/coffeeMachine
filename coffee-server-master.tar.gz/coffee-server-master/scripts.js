	google.load('visualization', '1', {packages:['gauge']});

	$(function() {
		var options = {
			lines: {
				show: true,
				fill: true,
			},
			points: {
				show: true
			},
			bars: {
			  align: "center",
			  barWidth: 60*60*24*1000
			},
			selection: {
				mode: "x"
			},
			xaxis: {
				mode: "time",
				tickLength: 5,
			},
			yaxes: [ {},
				{
				  // align if we are to the right
				  alignTicksWithAxis: 1,
				  position: "right",
				  tickFormatter: euroFormatter
				} ],
			grid: {
				markings: weekendAreas,
				hoverable: true, 
				clickable: true,
			},
			legend: {
			    position: "nw",
			},
		};
	
		function euroFormatter(v, axis) {
		    return v.toFixed(axis.tickDecimals) +"&euro;";
		}
	
		function weekendAreas(axes) {
			var markings = [],
				d = new Date(axes.xaxis.min);

			// go to the first Saturday
			d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 1) % 7))
			d.setUTCSeconds(0);
			d.setUTCMinutes(0);
			d.setUTCHours(-12); //weekend start after half a day

			var i = d.getTime();

			// when we don't set yaxis, the rectangle automatically
			// extends to infinity upwards and downwards

			do {
				markings.push({ xaxis: { from: i, to: i + (2 * 24 * 60 * 60 * 1000) } });
				i += 7 * 24 * 60 * 60 * 1000;
			} while (i < axes.xaxis.max);

			return markings;
		};

		// show the plot tooltip
		function showTooltip(x, y, contents) {
			$('<div id="tooltip">' + contents + '</div>').css( {
				position: 'absolute',
				display: 'none',
				top: y - 35,
				left: x + 5,
				border: '1px solid #fdd',
				padding: '2px',
				'background-color': '#fee',
				opacity: 0.80
			}).appendTo("body").fadeIn(200);
		}

		function interpolate(data, zeromode) {
		  
			var min=999999, max=-999999;
			/* helper function to find date differences*/
			function dateDiff(d1, d2) {
				return Math.floor((d2 - d1) / (1000 * 60 * 60 * 24));
			}

			//round to whole day
			data[0][0] = Math.floor(data[0][0]/ (1000 * 60 * 60 * 24)) * (1000 * 60 * 60 * 24);
			for (i = 1; i < data.length; i++) {
			  
			  
				min=Math.min(data[i][1], min);
				max=Math.max(data[i][1], max);
			  
				//round to whole day
				data[i][0] = Math.floor(data[i][0]/ (1000 * 60 * 60 * 24)) * (1000 * 60 * 60 * 24);

				var diff = dateDiff(data[i - 1][0], data[i][0]);
				var startDate = new Date(data[i - 1][0]);
				if (diff > 1) {
					var newValue=0;
					if(!zeromode) {
					   newValue=data[i-1][1];
					}
					for (j = 0; j < diff - 1; j++) {
						var fillDate = new Date(startDate).setDate(startDate.getDate() + (j + 1));
						data.splice(i+j,0,[fillDate, newValue]); 
					}
				}
			}
			
			return [min, max];
		}

		// Fetch one series, adding to what we already have
		var alreadyFetched = {};

		// Initiate a recurring data update
		function wurst(mode) {
			alreadyFetched = {};

			function fetchData() {

				function onDataReceived(series) {
					// Load all the data in one pass; if we only got partial
					// data we could merge it with what we already have.
					
					var extremi=[];
					
					//set days without value to zero
//					if(mode == "daily") {
					  for(var i=0; i < series.Kaffee.length; i++) {
					    var min, max;
					    [min,max]=interpolate(series.Kaffee[i].data, (i==series.Kaffee.length-1)?false:true);
					    extremi.push([min, max]);
					  }
//					}
					
 				        switch(mode) {
					case "daily":
					  options.bars.barWidth= 60*60*24*1000;
					  break;
					case "weekly":
					  options.bars.barWidth= 7*24*60*60*1000;
					  break;
					case "monthly":
					  options.bars.barWidth= 4*7*24*60*60*1000;
					  break;
					}
					
					var scale = extremi[0][1] / extremi[2][1];
					
					var newMin = Math.min(0,extremi[2][0] * scale);
					
					options.yaxes[0].min= Math.floor(newMin);
					options.yaxes[0].max= extremi[0][1];
					options.yaxes[1].min= Math.min(0, extremi[2][0]);
					options.yaxes[1].max= extremi[2][1];
					
					//document.write('<pre>'+JSON.stringify(data,null,' ')+'</pre>');
					series.Kaffee[0].lines={ show: false, fill: false};
					series.Kaffee[0].bars={ show: true};
					series.Kaffee[0].points={ show: false };

					series.Kaffee[1].lines={ show: false, fill: false};
					series.Kaffee[1].bars={ show: true};
					series.Kaffee[1].points={ show: false };

					
					series.Kaffee[2].lines={ show: true, fill: false};
					series.Kaffee[2].points={ show: false };
					var plot=$.plot("#placeholder", series.Kaffee, options);
					drawGauge(series.Gauge);
				}

				alreadyFetched = {};
				$.ajax({
					url: "daily_stats.php?token=<? echo $_REQUEST['token']; ?>&mode="+mode,
					type: "GET",
					dataType: "json",
					success: onDataReceived,
	  			        error: function (xhr, ajaxOptions, thrownError) {
						alert(xhr.status);
						alert(thrownError);
					      }
				});
				
			}

			//setTimeout(fetchData, 1000);
			fetchData();
			
		};
		
		function drawGauge(values) {
		
		
    
		      var curval=Math.ceil(values.current);
    
		      var data = google.visualization.arrayToDataTable([
			['Label', 'Value'],
			['Coffee', curval],
		      ]);

		      var redtoval=Math.ceil(values.maximum*1.10);
		      
		      var options = {
			width: 135, height: 135,
			max: redtoval,
			redFrom: values.maximum, redTo: redtoval,
			yellowFrom:values.average, yellowTo: values.maximum,
			minorTicks: 5
		      };

		      var chart = new google.visualization.Gauge(document.getElementById('gauge_div'));
		      chart.draw(data, options);
		}
		
/******************* MAIN *****************************/
		//Add mouseover handler to plot
		$("#placeholder").bind("plothover", function (event, pos, item) {
			$("#x").text(pos.x.toFixed(2));
			$("#y").text(pos.y.toFixed(2));

			if (item) {
				if (previousPoint != item.datapoint) {
					previousPoint = item.datapoint;
					$("#tooltip").remove();
					var x = item.datapoint[0], y = item.datapoint[1];
					var xDate = new Date(x);
					showTooltip(item.pageX, item.pageY, item.series.label + " of " + xDate.toDateString() + " = " + y);
				}
			}
			else {
				$("#tooltip").remove();
				previousPoint = null;            
			}

		});
		

		$("#tabs").tabs({ activate: function( event, ui ) {
					      wurst($(ui.newTab).attr('id'));
					    }
		});


		// Load the first series by default, so we don't have an empty plot
		wurst("daily");
		
		
		
	});
 

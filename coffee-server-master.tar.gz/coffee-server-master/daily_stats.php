<?php

    header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
    header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Datum in der Vergangenheit

    include("global_stuff.php");

    $gauge_values=array();
    $total_data = array();
    $personal_data = array();
    $credit_data = array();

    $unit="DAY";
    $group="%Y %m %d";
    
    switch($_REQUEST['mode']) {
      case "daily":
      default:
	$unit="DAY";
	$group="%Y %m %d";
	break;
      case "weekly":
	$unit="WEEK";
	$group="%Y %u";
	break;
      case "monthly":
	$unit="MONTH";
	$group="%Y %m";
	break;
    }


    $ergebnis=mysqli_query($link, "SELECT UNIX_TIMESTAMP(time) as datum, count(*) as summe FROM `protokoll` WHERE time > DATE_SUB( NOW( ) , INTERVAL 60 $unit ) AND value < -3 and value > -45 and UserID >= 1 group by DATE_FORMAT(time, '$group') ORDER BY time DESC LIMIT 0,60"); 
    for ($i=mysqli_num_rows($ergebnis)-1; $i>=0; $i--) {
	array_push($total_data, array((1000*mysqli_result($ergebnis,$i,"datum")), (1*mysqli_result($ergebnis,$i,"summe"))));
    }
  
    $userid = $_REQUEST['token']; 
    $ergebnis=mysqli_query($link, "SELECT UNIX_TIMESTAMP(time) as datum, count(*) as summe FROM `protokoll` WHERE time > DATE_SUB( NOW( ) , INTERVAL 60 $unit ) AND value < -3 and value > -45 and UserID = (SELECT userid from token where token=\"".mysqli_escape_string($userid)."\") group by DATE_FORMAT(time, '$group') ORDER BY time DESC LIMIT 0,60");
    for ($i=mysqli_num_rows($ergebnis)-1; $i>=0; $i--) {
	array_push($personal_data, array((1000*mysqli_result($ergebnis,$i,"datum")), (1*mysqli_result($ergebnis,$i,"summe"))) );
    }

    $ergebnis=mysqli_query($link, "SELECT sum(value) as summe FROM `protokoll` WHERE UserID = (SELECT userid from token where token=\"".mysqli_escape_string($userid)."\")");
    $Kontostand=mysqli_result($ergebnis,0,"summe");

  
    $ergebnis=mysqli_query($link, "SELECT UNIX_TIMESTAMP(time) as datum, sum(value) as summe FROM `protokoll` WHERE time > DATE_SUB( NOW( ) , INTERVAL 60 $unit ) AND UserID = (SELECT userid from token where token=\"".mysqli_escape_string($userid)."\") group by DATE_FORMAT(time, '$group') ORDER BY time DESC LIMIT 0,60");

    for ($i=0; $i<mysqli_num_rows($ergebnis); $i++) {
	$Kontostand-=mysqli_result($ergebnis,$i,"summe");
    }
    for ($i=mysqli_num_rows($ergebnis)-1; $i>=0; $i--) {
	$Kontostand+=mysqli_result($ergebnis,$i,"summe");
	array_push($credit_data, array( (1000*mysqli_result($ergebnis,$i,"datum")), ($Kontostand/100)) );
    }
    
    $ergebnis=mysqli_query($link, "SELECT avg( BLA.summe ) AS average, max( BLA.summe ) AS maximum, min( BLA.summe ) AS minimum
				FROM (
				SELECT count( * ) AS summe
				FROM `protokoll`
				WHERE 
				time < DATE_SUB( NOW( ) , INTERVAL 24 HOUR ) AND
				value <-3
				AND value > -45
				AND UserID = (SELECT userid from token where token=\"".mysqli_escape_string($userid)."\")
				GROUP BY DATE_FORMAT( time, '%Y %m %d' )
				ORDER BY time DESC				
				) AS BLA");

    $gauge_values["minimum"] = mysqli_result($ergebnis,0,"minimum");
    $gauge_values["average"] = mysqli_result($ergebnis,0,"average");    
    $gauge_values["maximum"] = mysqli_result($ergebnis,0,"maximum");
    
    $ergebnis=mysqli_query($link, "SELECT count(*) as summe FROM `protokoll` WHERE time > DATE_SUB( NOW( ) , INTERVAL 24 HOUR ) AND value < -3 and value > -45 and UserID = (SELECT userid from token where token=\"".mysqli_escape_string($userid)."\")");
   
    $gauge_values["current"] = mysqli_result($ergebnis,0,"summe");


$your_credit = array();
$your_credit["label"] = "Your credit";
$your_credit["yaxis"] =  2;
$your_credit['data'] = $credit_data;

$total_consumption=array();
$total_consumption["label"] = "Total Consumption";
$total_consumption['data'] = $total_data;

$personal_consumption = array();
$personal_consumption["label"] = "Your Consumption";
$personal_consumption['data'] = $personal_data;

$result  = array();
$result["Kaffee"] = array($total_consumption, $personal_consumption, $your_credit);
$result["Gauge"] = $gauge_values;

echo json_encode( $result);
?>

<?php

    header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
    header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Datum in der Vergangenheit

	$__CredPayment="2390489023841239234862347863g24khgdfjg,ejkghdfj";

include("global_stuff.php");

    if($_REQUEST['codewort'] != $__CredPayment) {
	die ("Wrong Code");
    }

    
    $UserID=substr($_REQUEST['user'],0, strpos($_REQUEST['user'],"_"));
    $val=$_REQUEST['value'];
    $reason=$_REQUEST['typ'];

    if($_REQUEST['consumeonly'] != "true") {

		$Mode="Withdraw";
		if($val > 0) $Mode="Deposit";
		$sql = "INSERT INTO `protokoll` (`id`, `UserID`, `Time`, `Value`, `Kommentar`, `ActionID`) VALUES (NULL, ".mysqli_real_escape_string($link, $UserID).", CURRENT_TIMESTAMP, ".mysqli_real_escape_string($link, $val).", 'eingezahlt (".mysqli_real_escape_string($link, $reason).")', (SELECT id from actions where text='$Mode Money'));";
		echo mysqli_query($link, $sql);


    }
    if($_REQUEST['consumeonly'] == "true" || $_REQUEST['consume'] == "true" ) {
	$val=-$val;
		$sql = "INSERT INTO `protokoll` (`id`, `UserID`, `Time`, `Value`, `Kommentar`, `ActionID`) VALUES (NULL, 0 , CURRENT_TIMESTAMP, ".mysqli_real_escape_string($link, $val).", 'verbraucht (".mysqli_real_escape_string($link, $reason).")', (SELECT id from actions where text='Consumables'));";
		echo mysqli_query($link, $sql);

    }


?>

<a href="kasse.php">back zur Kasse</a>

</body></html>

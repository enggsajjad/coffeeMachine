import pytest
import user

def test_commit():
    